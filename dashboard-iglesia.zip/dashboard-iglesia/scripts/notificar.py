# -*- coding: utf-8 -*-
import json
import datetime
import requests
import os

# Archivo de base de datos
DATA_FILE = "data.json"

def enviar_mensaje_whatsapp(telefono, mensaje):
    """
    Envía una notificación vía WhatsApp utilizando la API pública y gratuita de CallMeBot.
    Para que funcione, el destinatario debe haber activado previamente su bot de CallMeBot.
    En un entorno real, puedes usar Twilio, Meta WhatsApp API u otros servicios de mensajería.
    """
    # Reemplazar con tus credenciales de CallMeBot (Configurables mediante GitHub Secrets)
    api_key = os.environ.get("CALLMEBOT_API_KEY", "TU_CALLMEBOT_API_KEY")
    
    if api_key == "TU_CALLMEBOT_API_KEY":
        print(f"[MOCK-SMS/WhatsApp] Destinatario: {telefono} | Mensaje: {mensaje}")
        return True
        
    url = f"https://api.callmebot.com/whatsapp.php?phone={telefono}&text={mensaje}&apikey={api_key}"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            print(f"Mensaje enviado con éxito a {telefono}")
            return True
        else:
            print(f"Error al enviar a {telefono}: {response.text}")
            return False
    except Exception as e:
        print(f"Fallo al conectar con la API de notificaciones: {e}")
        return False

def procesar_notificaciones():
    if not os.path.exists(DATA_FILE):
        print("El archivo de datos no existe.")
        return
        
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    hoy = datetime.date.today()
    manana = hoy + datetime.timedelta(days=1)
    manana_str = manana.strftime("%Y-%m-%d")
    
    # 1. Buscar predicaciones para mañana
    predicaciones_manana = [p for p in data.get("predicaciones", []) if p["fecha"] == manana_str]
    
    for p in predicaciones_manana:
        predicador = next((pr for pr in data.get("predicadores", []) if pr["id"] == p["predicadorId"]), None)
        if predicador:
            nombre = predicador["nombre"]
            telefono = predicador["telefono"]
            libro = p["libro"]
            capitulo = p["capitulo"]
            tema = p["tema"]
            hora = p["hora"]
            
            # Construir mensaje de WhatsApp
            mensaje = (
                f"Hola {nombre}. Te recordamos desde Intelly que mañana Domingo "
                f"te corresponde predicar a las {hora}. El pasaje bíblico "
                f"asignado es {libro} {capitulo} con el tema: '{tema}'. ¡Bendiciones!"
            )
            
            # Encriptar caracteres para URL
            mensaje_codificado = requests.utils.quote(mensaje)
            enviar_mensaje_whatsapp(telefono, mensaje_codificado)

    # 2. Buscar eventos generales de la iglesia para mañana
    eventos_manana = [e for e in data.get("eventos", []) if e["fecha"] == manana_str]
    for e in eventos_manana:
        titulo = e["titulo"]
        hora = e["hora"]
        desc = e["descripcion"]
        
        # Enviar aviso general o a coordinadores
        # Aquí se podría disparar una notificación a un grupo de WhatsApp usando una integración compatible.
        print(f"[Recordatorio de Evento] Mañana se celebra el evento: '{titulo}' a las {hora}. Detalles: {desc}")

if __name__ == "__main__":
    print("Iniciando escaneo diario de notificaciones...")
    procesar_notificaciones()
    print("Escaneo finalizado.")
