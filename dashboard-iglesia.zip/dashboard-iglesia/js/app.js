// Estado de la Aplicación
let appState = {
    predicadores: [],
    predicaciones: [],
    eventos: []
};

// Configuración de fecha por defecto
let currentDate = new Date();
let selectedDate = new Date();
let chartInstance = null;

// Inicialización de la Aplicación
document.addEventListener("DOMContentLoaded", () => {
    // Validar Sesión
    if (localStorage.getItem("church_logged_in") === "true") {
        document.getElementById("login-screen").classList.add("hidden");
        document.getElementById("app-container").classList.remove("hidden");
        initApp();
    }
});

// Manejo de Login
document.getElementById("login-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("login-email").value;
    const pass = document.getElementById("login-password").value;

    if (pass === "iglesia123") {
        localStorage.setItem("church_logged_in", "true");
        localStorage.setItem("church_user_email", email);
        
        document.getElementById("login-screen").classList.add("hidden");
        document.getElementById("app-container").classList.remove("hidden");
        
        initApp();
    } else {
        alert("Contraseña incorrecta. Intenta con 'iglesia123'");
    }
});

function logout() {
    localStorage.removeItem("church_logged_in");
    localStorage.removeItem("church_user_email");
    window.location.reload();
}

// Carga Inicial de Datos
async function initApp() {
    // Definir usuario en la interfaz
    const userEmail = localStorage.getItem("church_user_email") || "admin@iglesia.com";
    document.getElementById("user-display-email").innerText = userEmail;
    const initials = userEmail.substring(0, 2).toUpperCase();
    document.getElementById("avatar-iniciales").innerText = initials;
    document.getElementById("user-display-name").innerText = userEmail.split('@')[0];

    // Saludo Dinámico
    const hour = new Date().getHours();
    let greeting = "Buenos días";
    if (hour >= 12 && hour < 19) greeting = "Buenas tardes";
    else if (hour >= 19 || hour < 5) greeting = "Buenas noches";
    document.getElementById("dynamic-greeting").innerText = `${greeting}, Iglesia 👋`;

    // Intentar leer de localStorage, si no, usar data.json
    const localData = localStorage.getItem("church_dashboard_data");
    if (localData) {
        appState = JSON.parse(localData);
        renderAll();
    } else {
        try {
            const response = await fetch('data.json');
            if (response.ok) {
                appState = await response.json();
                saveLocal();
                renderAll();
            } else {
                cargarFallbackMock();
            }
        } catch (err) {
            console.warn("No se pudo cargar data.json directamente (común en apertura de archivos localmente). Cargando Mock de Respaldo.");
            cargarFallbackMock();
        }
    }
}

function cargarFallbackMock() {
    // Si falla el fetch por CORS, cargamos estructura básica
    appState = {
        predicadores: [
            {"id": 1, "nombre": "Pastor Alejandro Gómez", "tipo": "Local", "email": "alejandro@iglesia.com", "telefono": "+56912345678"},
            {"id": 2, "nombre": "Dra. Olivia Silva", "tipo": "Invitada", "email": "olivia.silva@email.com", "telefono": "+56987654321"},
            {"id": 3, "nombre": "Hno. Carlos Mendoza", "tipo": "Local", "email": "carlos@iglesia.com", "telefono": "+56955554444"}
        ],
        predicaciones: [
            {"id": 1, "fecha": "2026-07-19", "predicadorId": 1, "libro": "Romanos", "capitulo": "8", "tema": "Vida en el Espíritu", "hora": "10:00 AM"},
            {"id": 2, "fecha": "2026-07-26", "predicadorId": 2, "libro": "Efesios", "capitulo": "2", "tema": "Salvos por Gracia", "hora": "10:00 AM"}
        ],
        eventos: [
            {"id": 1, "fecha": "2026-07-22", "titulo": "Reunión de Oración", "hora": "19:30", "descripcion": "Intercesión."},
            {"id": 2, "fecha": "2026-07-25", "titulo": "Concierto Juvenil", "hora": "18:00", "descripcion": "Adoración."}
        ]
    };
    saveLocal();
    renderAll();
}

function saveLocal() {
    localStorage.setItem("church_dashboard_data", JSON.stringify(appState));
}

// Cambiar de Pestaña (Navegación Sidebar)
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.add('hidden'));
    document.getElementById(`tab-${tabName}`).classList.remove('hidden');

    // Estilos del nav link activo
    document.querySelectorAll('aside nav a').forEach(a => {
        a.className = "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition duration-150 text-zinc-400 hover:text-white hover:bg-zinc-900";
    });
    
    let activeNav = document.getElementById(`nav-${tabName}`);
    if (!activeNav && tabName === 'predicadores') activeNav = document.getElementById('nav-predicadores-tab');
    
    if (activeNav) {
        activeNav.className = "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition duration-150 bg-zinc-800 text-white";
    }
}

// Renderizar todo
function renderAll() {
    renderKPIs();
    renderSermonsTable();
    renderBiblicalBooksChart();
    renderCalendar();
    renderEvents();
    renderPreachersLists();
}

// Render de Indicadores Clave (KPIs)
function renderKPIs() {
    const hoyStr = new Date().toISOString().split('T')[0];
    
    // 1. Próxima Predicación
    const proximasSermons = appState.predicaciones
        .filter(s => s.fecha >= hoyStr)
        .sort((a,b) => a.fecha.localeCompare(b.fecha));
        
    if (proximasSermons.length > 0) {
        const next = proximasSermons[0];
        const preacher = appState.predicadores.find(p => p.id == next.predicadorId);
        document.getElementById("kpi-next-sermon").innerText = `${next.libro} ${next.capitulo}`;
        document.getElementById("kpi-next-sermon-details").innerText = `${preacher ? preacher.nombre : 'Por definir'} • ${formatDateDisplay(next.fecha)}`;
    } else {
        document.getElementById("kpi-next-sermon").innerText = "Sin programar";
        document.getElementById("kpi-next-sermon-details").innerText = "Agenda un sermón para domingo";
    }

    // 2. Evento Cercano
    const proximosEventos = appState.eventos
        .filter(e => e.fecha >= hoyStr)
        .sort((a,b) => a.fecha.localeCompare(b.fecha));

    if (proximosEventos.length > 0) {
        const nextEv = proximosEventos[0];
        document.getElementById("kpi-next-event").innerText = nextEv.titulo;
        document.getElementById("kpi-next-event-details").innerText = `${formatDateDisplay(nextEv.fecha)} • ${nextEv.hora}`;
    } else {
        document.getElementById("kpi-next-event").innerText = "No hay eventos";
        document.getElementById("kpi-next-event-details").innerText = "Registra un evento pronto";
    }

    // 3. Libro Más Estudiado
    const booksCount = {};
    appState.predicaciones.forEach(p => {
        booksCount[p.libro] = (booksCount[p.libro] || 0) + 1;
    });
    let topBook = "Ninguno";
    let topCount = 0;
    for (const [bk, ct] of Object.entries(booksCount)) {
        if (ct > topCount) {
            topCount = ct;
            topBook = bk;
        }
    }
    document.getElementById("kpi-top-book").innerText = topBook;
    document.getElementById("kpi-top-book-details").innerText = topCount > 0 ? `Estudiado ${topCount} veces` : 'Comienza a programar';

    // 4. Predicadores Activos
    document.getElementById("kpi-total-preachers").innerText = `${appState.predicadores.length} Activos`;
    const localesCount = appState.predicadores.filter(p => p.type === 'Local' || p.tipo === 'Local').length;
    document.getElementById("kpi-total-preachers-details").innerText = `${localesCount} locales, ${appState.predicadores.length - localesCount} invitados`;
}

// Render de Tablas de Predicación
function renderSermonsTable() {
    const tableBody = document.getElementById("sermons-table-body");
    const fullSermonsTable = document.getElementById("full-sermons-table");
    tableBody.innerHTML = "";
    fullSermonsTable.innerHTML = "";

    // Ordenar predicaciones por fecha descendente para el historial
    const sortedSermons = [...appState.predicaciones].sort((a,b) => b.fecha.localeCompare(a.fecha));

    // Llenar tabla del Dashboard (solo los próximos o últimos 4)
    const dashboardSermons = sortedSermons.slice(0, 4);
    dashboardSermons.forEach(s => {
        const preacher = appState.predicadores.find(p => p.id == s.predicadorId) || { nombre: "Desconocido" };
        const isInvitado = preacher.tipo === "Invitado";
        
        const row = document.createElement("tr");
        row.className = "hover:bg-slate-50 transition duration-150";
        row.innerHTML = `
            <td class="py-4 px-2">
                <div class="flex items-center gap-2">
                    <span class="font-semibold text-slate-900">${preacher.nombre}</span>
                    ${isInvitado ? `<span class="bg-purple-100 text-purple-700 text-[10px] px-2 py-0.5 rounded-full font-bold">Invitado</span>` : ""}
                </div>
            </td>
            <td class="py-4 px-2">
                <div class="text-slate-900 font-medium">${s.libro} ${s.capitulo}</div>
                <div class="text-xs text-slate-400 truncate max-w-xs">${s.tema}</div>
            </td>
            <td class="py-4 px-2 text-xs">
                <div class="text-slate-800 font-semibold">${formatDateDisplay(s.fecha)}</div>
                <div class="text-slate-400">${s.hora}</div>
            </td>
            <td class="py-4 px-2">
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Automático
                </span>
            </td>
        `;
        tableBody.appendChild(row);
    });

    // Llenar tabla del historial completo
    sortedSermons.forEach(s => {
        const preacher = appState.predicadores.find(p => p.id == s.predicadorId) || { nombre: "Desconocido" };
        const row = document.createElement("tr");
        row.innerHTML = `
            <td class="py-4 px-4 font-semibold text-slate-900">${formatDateDisplay(s.fecha)}</td>
            <td class="py-4 px-4">${preacher.nombre}</td>
            <td class="py-4 px-4 font-medium text-slate-900">${s.libro}</td>
            <td class="py-4 px-4">${s.tema} (${s.capitulo})</td>
            <td class="py-4 px-4 text-xs text-slate-500">${s.hora}</td>
            <td class="py-4 px-4 text-right space-x-2">
                <button onclick="editarPredicacion(${s.id})" class="text-blue-500 hover:text-blue-700 text-sm"><i class="fa-solid fa-pen"></i></button>
                <button onclick="eliminarPredicacion(${s.id})" class="text-rose-500 hover:text-rose-700 text-sm"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;
        fullSermonsTable.appendChild(row);
    });
}

// Render de Gráfico (Chart.js)
function renderBiblicalBooksChart() {
    const ctx = document.getElementById('biblicalBooksChart').getContext('2d');
    
    // Contar libros
    const counts = {};
    appState.predicaciones.forEach(p => {
        counts[p.libro] = (counts[p.libro] || 0) + 1;
    });

    const labels = Object.keys(counts);
    const data = Object.values(counts);

    if (chartInstance) {
        chartInstance.destroy();
    }

    chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sermones predicados',
                data: data,
                backgroundColor: [
                    'rgba(253, 242, 231, 0.9)', // Soft Yellowish
                    'rgba(253, 226, 243, 0.9)', // Soft Pink
                    'rgba(223, 249, 230, 0.9)', // Soft Green
                    'rgba(221, 235, 255, 0.9)'  // Soft Blue
                ],
                borderColor: [
                    '#fde047',
                    '#fbcfe8',
                    '#bbf7d0',
                    '#bfdbfe'
                ],
                borderWidth: 1.5,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 }
                }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });
}

// Render de Calendario Interactivo
function renderCalendar() {
    const grid = document.getElementById("calendar-grid");
    const monthYearLabel = document.getElementById("calendar-month-year");
    grid.innerHTML = "";

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    monthYearLabel.innerText = `${monthNames[month]} ${year}`;

    const firstDayIndex = new Date(year, month, 1).getDay();
    const lastDay = new Date(year, month + 1, 0).getDate();
    const prevLastDay = new Date(year, month, 0).getDate();

    // Días del mes anterior para rellenar
    for (let x = firstDayIndex; x > 0; x--) {
        const div = document.createElement("div");
        div.className = "text-slate-300 py-1.5 text-xs";
        div.innerText = prevLastDay - x + 1;
        grid.appendChild(div);
    }

    // Días del mes actual
    for (let i = 1; i <= lastDay; i++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        
        // Comprobar si hay evento o predicación en este día
        const tienePredicacion = appState.predicaciones.some(s => s.fecha === dateStr);
        const tieneEvento = appState.eventos.some(e => e.fecha === dateStr);

        const div = document.createElement("div");
        div.className = "relative py-1.5 cursor-pointer hover:bg-slate-100 rounded-lg transition text-xs font-semibold text-slate-700 flex flex-col items-center justify-center h-8 w-8 mx-auto";
        div.innerText = i;
        
        // Resaltar día de hoy
        const hoyStr = new Date().toISOString().split('T')[0];
        if (dateStr === hoyStr) {
            div.className += " bg-slate-900 text-white hover:bg-slate-800 rounded-full";
        }

        // Puntitos indicadores de actividades
        if (tienePredicacion || tieneEvento) {
            const indicator = document.createElement("span");
            indicator.className = "absolute bottom-1 w-1 h-1 rounded-full bg-pink-500";
            if (dateStr === hoyStr) indicator.className += " bg-white";
            div.appendChild(indicator);
        }

        div.onclick = () => verDetalleDia(dateStr);
        grid.appendChild(div);
    }
}

function changeMonth(direction) {
    currentDate.setMonth(currentDate.getMonth() + direction);
    renderCalendar();
}

function verDetalleDia(fechaStr) {
    const evs = appState.eventos.filter(e => e.fecha === fechaStr);
    const sers = appState.predicaciones.filter(s => s.fecha === fechaStr);

    let info = `Actividades para el ${formatDateDisplay(fechaStr)}:\n\n`;
    if (sers.length > 0) {
        sers.forEach(s => {
            const preacher = appState.predicadores.find(p => p.id == s.predicadorId);
            info += `• Predicación: ${s.libro} ${s.capitulo} - "${s.tema}" por ${preacher ? preacher.nombre : 'Por definir'} a las ${s.hora}\n`;
        });
    }
    if (evs.length > 0) {
        evs.forEach(e => {
            info += `• Evento: ${e.titulo} (${e.hora}) - ${e.descripcion}\n`;
        });
    }

    if (sers.length === 0 && evs.length === 0) {
        info += "No hay actividades programadas para este día.";
    }

    alert(info);
}

// Render de Lista de Eventos Próximos
function renderEvents() {
    const list = document.getElementById("upcoming-events-list");
    const fullEventsTable = document.getElementById("full-events-table");
    list.innerHTML = "";
    fullEventsTable.innerHTML = "";

    const hoyStr = new Date().toISOString().split('T')[0];
    const sortedEvents = [...appState.eventos].sort((a,b) => a.fecha.localeCompare(b.fecha));

    // Filtrar próximos para panel lateral
    const proximos = sortedEvents.filter(e => e.fecha >= hoyStr).slice(0, 3);

    if (proximos.length === 0) {
        list.innerHTML = `<p class="text-xs text-slate-400 italic">No hay próximos eventos agendados.</p>`;
    } else {
        proximos.forEach(e => {
            const div = document.createElement("div");
            div.className = "flex gap-3 items-start p-3 hover:bg-slate-50 rounded-2xl transition duration-150";
            div.innerHTML = `
                <div class="p-2 rounded-xl bg-pink-50 text-pink-500">
                    <i class="fa-solid fa-calendar-day text-sm"></i>
                </div>
                <div>
                    <h4 class="text-xs font-bold text-slate-900">${e.titulo}</h4>
                    <p class="text-[10px] text-slate-500">${formatDateDisplay(e.fecha)} • ${e.hora}</p>
                    <p class="text-[10px] text-slate-400 mt-0.5 line-clamp-1">${e.descripcion}</p>
                </div>
            `;
            list.appendChild(div);
        });
    }

    // Tabla Completa en pestaña de Agenda
    sortedEvents.forEach(e => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td class="py-4 px-4 font-semibold text-slate-900">${formatDateDisplay(e.fecha)}</td>
            <td class="py-4 px-4 font-medium text-slate-900">${e.titulo}</td>
            <td class="py-4 px-4 text-xs text-slate-500">${e.hora}</td>
            <td class="py-4 px-4 text-slate-500 text-xs">${e.descripcion}</td>
            <td class="py-4 px-4 text-right space-x-2">
                <button onclick="editarEvento(${e.id})" class="text-blue-500 hover:text-blue-700 text-sm"><i class="fa-solid fa-pen"></i></button>
                <button onclick="eliminarEvento(${e.id})" class="text-rose-500 hover:text-rose-700 text-sm"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;
        fullEventsTable.appendChild(row);
    });
}

// Renderizar Predicadores
function renderPreachersLists() {
    const listSelect = document.getElementById("sermon-preacher");
    const fullPreachersTable = document.getElementById("full-preachers-table");
    
    listSelect.innerHTML = `<option value="">Selecciona un predicador...</option>`;
    fullPreachersTable.innerHTML = "";

    appState.predicadores.forEach(p => {
        // Opción para select de sermón
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.innerText = `${p.nombre} (${p.tipo})`;
        listSelect.appendChild(opt);

        // Registro de tabla
        const row = document.createElement("tr");
        row.innerHTML = `
            <td class="py-4 px-4 font-semibold text-slate-900">${p.nombre}</td>
            <td class="py-4 px-4">
                <span class="px-2 py-1 rounded-full text-xs font-semibold ${p.tipo === 'Invitado' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-700'}">
                    ${p.tipo}
                </span>
            </td>
            <td class="py-4 px-4 text-slate-500 text-xs">${p.email}</td>
            <td class="py-4 px-4 text-slate-500 text-xs">${p.telefono}</td>
            <td class="py-4 px-4 text-right space-x-2">
                <button onclick="editarPredicador(${p.id})" class="text-blue-500 hover:text-blue-700 text-sm"><i class="fa-solid fa-pen"></i></button>
                <button onclick="eliminarPredicador(${p.id})" class="text-rose-500 hover:text-rose-700 text-sm"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;
        fullPreachersTable.appendChild(row);
    });
}

// GESTIÓN DE ACCIONES (CREACIÓN / EDICIÓN)

// 1. Predicaciones
function abrirModalPredicacion() {
    document.getElementById("form-predicacion").reset();
    document.getElementById("edit-predicacion-id").value = "";
    document.getElementById("modal-predicacion").style.display = "flex";
}

document.getElementById("form-predicacion").addEventListener("submit", (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-predicacion-id").value;
    const newSermon = {
        id: id ? parseInt(id) : Date.now(),
        predicadorId: parseInt(document.getElementById("sermon-preacher").value),
        libro: document.getElementById("sermon-book").value,
        capitulo: document.getElementById("sermon-chapter").value,
        tema: document.getElementById("sermon-topic").value,
        fecha: document.getElementById("sermon-date").value,
        hora: document.getElementById("sermon-time").value
    };

    if (id) {
        const index = appState.predicaciones.findIndex(s => s.id === parseInt(id));
        appState.predicaciones[index] = newSermon;
    } else {
        appState.predicaciones.push(newSermon);
    }

    saveLocal();
    renderAll();
    cerrarModal('predicacion');
});

function editarPredicacion(id) {
    const s = appState.predicaciones.find(x => x.id === id);
    if (!s) return;
    document.getElementById("edit-predicacion-id").value = s.id;
    document.getElementById("sermon-preacher").value = s.predicadorId;
    document.getElementById("sermon-book").value = s.libro;
    document.getElementById("sermon-chapter").value = s.capitulo;
    document.getElementById("sermon-topic").value = s.tema;
    document.getElementById("sermon-date").value = s.fecha;
    document.getElementById("sermon-time").value = s.hora;
    document.getElementById("modal-predicacion").style.display = "flex";
}

function eliminarPredicacion(id) {
    if (confirm("¿Estás seguro de que deseas eliminar esta predicación?")) {
        appState.predicaciones = appState.predicaciones.filter(s => s.id !== id);
        saveLocal();
        renderAll();
    }
}

// 2. Eventos
function abrirModalEvento() {
    document.getElementById("form-evento").reset();
    document.getElementById("edit-evento-id").value = "";
    document.getElementById("modal-evento").style.display = "flex";
}

document.getElementById("form-evento").addEventListener("submit", (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-evento-id").value;
    const newEvent = {
        id: id ? parseInt(id) : Date.now(),
        titulo: document.getElementById("event-title").value,
        fecha: document.getElementById("event-date").value,
        hora: document.getElementById("event-time").value,
        descripcion: document.getElementById("event-desc").value
    };

    if (id) {
        const index = appState.eventos.findIndex(ev => ev.id === parseInt(id));
        appState.eventos[index] = newEvent;
    } else {
        appState.eventos.push(newEvent);
    }

    saveLocal();
    renderAll();
    cerrarModal('evento');
});

function editarEvento(id) {
    const ev = appState.eventos.find(x => x.id === id);
    if (!ev) return;
    document.getElementById("edit-evento-id").value = ev.id;
    document.getElementById("event-title").value = ev.titulo;
    document.getElementById("event-date").value = ev.fecha;
    document.getElementById("event-time").value = ev.hora;
    document.getElementById("event-desc").value = ev.descripcion;
    document.getElementById("modal-evento").style.display = "flex";
}

function eliminarEvento(id) {
    if (confirm("¿Estás seguro de que deseas eliminar este evento?")) {
        appState.eventos = appState.eventos.filter(e => e.id !== id);
        saveLocal();
        renderAll();
    }
}

// 3. Predicadores
function abrirModalPredicador() {
    document.getElementById("form-predicador").reset();
    document.getElementById("edit-predicador-id").value = "";
    document.getElementById("modal-predicador").style.display = "flex";
}

document.getElementById("form-predicador").addEventListener("submit", (e) => {
    e.preventDefault();
    const id = document.getElementById("edit-predicador-id").value;
    const newPreacher = {
        id: id ? parseInt(id) : Date.now(),
        nombre: document.getElementById("preacher-name").value,
        tipo: document.getElementById("preacher-type").value,
        email: document.getElementById("preacher-email").value,
        telefono: document.getElementById("preacher-phone").value
    };

    if (id) {
        const index = appState.predicadores.findIndex(p => p.id === parseInt(id));
        appState.predicadores[index] = newPreacher;
    } else {
        appState.predicadores.push(newPreacher);
    }

    saveLocal();
    renderAll();
    cerrarModal('predicador');
});

function editarPredicador(id) {
    const p = appState.predicadores.find(x => x.id === id);
    if (!p) return;
    document.getElementById("edit-predicador-id").value = p.id;
    document.getElementById("preacher-name").value = p.nombre;
    document.getElementById("preacher-type").value = p.tipo;
    document.getElementById("preacher-email").value = p.email;
    document.getElementById("preacher-phone").value = p.telefono;
    document.getElementById("modal-predicador").style.display = "flex";
}

function eliminarPredicador(id) {
    if (confirm("¿Estás seguro de que deseas eliminar este predicador del directorio?")) {
        appState.predicadores = appState.predicadores.filter(p => p.id !== id);
        saveLocal();
        renderAll();
    }
}

// Cierre de Modales
function cerrarModal(name) {
    document.getElementById(`modal-${name}`).style.display = "none";
}

// EXPORTAR BASE DE DATOS JSON (PARA GITHUB)
function abrirModalExportar() {
    document.getElementById("json-textarea").value = JSON.stringify(appState, null, 2);
    document.getElementById("modal-exportar").style.display = "flex";
}

function cerrarModalExportar() {
    document.getElementById("modal-exportar").style.display = "none";
}

function copiarJSON() {
    const textarea = document.getElementById("json-textarea");
    textarea.select();
    document.execCommand("copy");
    alert("¡Código copiado! Pégalo en tu archivo `data.json` de tu repositorio de GitHub para sincronizar permanentemente.");
}

// EXPORTACIÓN DEL CALENDARIO COMO IMAGEN (Para WhatsApp)
function exportCalendarAsImage() {
    const element = document.getElementById("calendar-export-card");
    
    // Ocultar temporalmente el botón de exportación para que no salga en la imagen
    const btn = element.querySelector("button");
    const headerBtns = element.querySelector(".flex.gap-1");
    btn.style.display = "none";
    headerBtns.style.display = "none";

    html2canvas(element, {
        backgroundColor: "#ffffff",
        scale: 2 // Mayor calidad de imagen
    }).then(canvas => {
        const link = document.createElement("a");
        link.download = `calendario-iglesia-${currentDate.getFullYear()}-${currentDate.getMonth() + 1}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
        
        // Restaurar botones
        btn.style.display = "flex";
        headerBtns.style.display = "flex";
    });
}

// Formateador de Fecha Auxiliar
function formatDateDisplay(dateStr) {
    const parts = dateStr.split('-');
    const dt = new Date(parts[0], parts[1] - 1, parts[2]);
    const dias = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
    const meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    return `${dias[dt.getDay()]}, ${dt.getDate()} de ${meses[dt.getMonth()]}`;
}
